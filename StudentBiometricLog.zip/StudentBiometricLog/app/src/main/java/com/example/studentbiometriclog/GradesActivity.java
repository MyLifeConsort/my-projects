package com.example.studentbiometriclog;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;


import androidx.appcompat.app.AppCompatActivity;

public class GradesActivity extends AppCompatActivity {

    ListView listViewGrades;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grades);

        listViewGrades = findViewById(R.id.listViewGrades);

        // Example grades
        String[] grades = {
                "Mathematics: A",
                "Physics: B+",
                "Computer Science: A-",
                "English Literature: B"
        };

        // Adapter for displaying grades
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, grades);

        listViewGrades.setAdapter(adapter);
    }
}
