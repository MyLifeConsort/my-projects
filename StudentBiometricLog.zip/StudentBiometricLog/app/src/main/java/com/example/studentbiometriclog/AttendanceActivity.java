package com.example.studentbiometriclog;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AttendanceActivity extends AppCompatActivity {

    Button btnScanBiometric;
    TextView tvScanResult, tvTimestamp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        btnScanBiometric = findViewById(R.id.btnScanBiometric);
        tvScanResult = findViewById(R.id.tvScanResult);
        tvTimestamp = findViewById(R.id.tvTimestamp);

        btnScanBiometric.setOnClickListener(v -> {
            // Placeholder biometric scan
            boolean scanSuccess = Math.random() > 0.3; // random success/failure

            if (scanSuccess) {
                tvScanResult.setText("Status: Scan Successful ✅");
                Toast.makeText(this, "Attendance Marked", Toast.LENGTH_SHORT).show();
            } else {
                tvScanResult.setText("Status: Scan Failed ❌");
                Toast.makeText(this, "Scan Failed", Toast.LENGTH_SHORT).show();
            }

            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
            tvTimestamp.setText("Timestamp: " + timestamp);
        });
    }
}
