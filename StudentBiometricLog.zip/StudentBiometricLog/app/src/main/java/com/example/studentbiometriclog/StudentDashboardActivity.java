package com.example.studentbiometriclog;
import com.example.studentbiometriclog.CheckGradesActivity;
import com.example.studentbiometriclog.ViewCoursesActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class StudentDashboardActivity extends AppCompatActivity {

    Button btnViewCourses, btnCheckGrades, btnLogout, btnMarkAttendance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_dashboard);

        // Link buttons from XML
        btnViewCourses = findViewById(R.id.btnViewCourses);
        btnCheckGrades = findViewById(R.id.btnCheckGrades);
        btnMarkAttendance = findViewById(R.id.btnMarkAttendance);
        btnLogout = findViewById(R.id.btnLogout);

        // Handle "View Courses" click → Navigate to ViewCoursesActivity
        btnViewCourses.setOnClickListener(v -> {
            Intent intent = new Intent(StudentDashboardActivity.this, ViewCoursesActivity.class);
            startActivity(intent);
        });

        // Handle "Check Grades" click → Navigate to CheckGradesActivity
        btnCheckGrades.setOnClickListener(v -> {
            Intent intent = new Intent(StudentDashboardActivity.this, CheckGradesActivity.class);
            startActivity(intent);
        });

        // Handle "Mark Attendance" click → Navigate to MarkAttendanceActivity
        btnMarkAttendance.setOnClickListener(v -> {
            Intent intent = new Intent(StudentDashboardActivity.this, AttendanceOptionsActivity.class);
            startActivity(intent);
        });


        // Handle "Logout" click
        btnLogout.setOnClickListener(v -> {
            Toast.makeText(StudentDashboardActivity.this,
                    "Logged out",
                    Toast.LENGTH_SHORT).show();

            // Go back to login screen
            Intent intent = new Intent(StudentDashboardActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Prevent going back to dashboard
        });
    }
}
