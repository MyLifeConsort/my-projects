package com.example.studentbiometriclog;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class TeacherDashboardActivity extends AppCompatActivity {

    Button btnTakeAttendance, btnViewLogs, btnReports;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_dashboard);

        btnTakeAttendance = findViewById(R.id.btnTakeAttendance);
        btnViewLogs = findViewById(R.id.btnViewLogs);
        btnReports = findViewById(R.id.btnReports);

        // Placeholder for button actions
        btnTakeAttendance.setOnClickListener(v -> {
            // TODO: Go to attendance screen
        });

        btnViewLogs.setOnClickListener(v -> {
            // TODO: Go to logs screen
        });

        btnReports.setOnClickListener(v -> {
            // TODO: Go to report screen
        });
    }
}
