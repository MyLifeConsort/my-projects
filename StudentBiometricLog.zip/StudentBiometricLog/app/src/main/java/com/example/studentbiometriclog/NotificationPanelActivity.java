package com.example.studentbiometriclog;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class NotificationPanelActivity extends AppCompatActivity {

    EditText etAlertMessage;
    Button btnSendAlert;
    ListView lvAlerts;
    ArrayAdapter<String> alertAdapter;
    List<String> alertHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_panel);

        etAlertMessage = findViewById(R.id.etAlertMessage);
        btnSendAlert = findViewById(R.id.btnSendAlert);
        lvAlerts = findViewById(R.id.lvAlerts);

        alertHistory = new ArrayList<>();
        alertAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, alertHistory);
        lvAlerts.setAdapter(alertAdapter);

        btnSendAlert.setOnClickListener(v -> {
            String message = etAlertMessage.getText().toString().trim();
            if (message.isEmpty()) {
                Toast.makeText(this, "Please enter a message", Toast.LENGTH_SHORT).show();
            } else {
                alertHistory.add("Alert: " + message);
                alertAdapter.notifyDataSetChanged();
                etAlertMessage.setText("");
                Toast.makeText(this, "Alert Sent (Placeholder)", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
