package com.example.studentbiometriclog;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class CoursesActivity extends AppCompatActivity {

    ListView listViewCourses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses); // Ensures you're using the correct layout XML file.

        // Link the ListView from the layout file to the Java code
        listViewCourses = findViewById(R.id.listViewCourses);

        // Example course list
        String[] courses = {"Mathematics", "Physics", "Computer Science", "English Literature"};

        // Adapter to display the list
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, courses);

        // Set the adapter to the ListView
        listViewCourses.setAdapter(adapter);
    }
}
