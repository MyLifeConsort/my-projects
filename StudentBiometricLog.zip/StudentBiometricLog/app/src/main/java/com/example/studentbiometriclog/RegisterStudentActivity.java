package com.example.studentbiometriclog;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterStudentActivity extends AppCompatActivity {

    EditText etStudentName, etStudentId;
    Button btnCaptureFingerprint, btnCaptureFace, btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_student);

        etStudentName = findViewById(R.id.etStudentName);
        etStudentId = findViewById(R.id.etStudentId);
        btnCaptureFingerprint = findViewById(R.id.btnCaptureFingerprint);
        btnCaptureFace = findViewById(R.id.btnCaptureFace);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnCaptureFingerprint.setOnClickListener(v -> {
            // Placeholder for fingerprint capture
            Toast.makeText(this, "Fingerprint Captured (Placeholder)", Toast.LENGTH_SHORT).show();
        });

        btnCaptureFace.setOnClickListener(v -> {
            // Placeholder for facial capture
            Toast.makeText(this, "Facial Image Captured (Placeholder)", Toast.LENGTH_SHORT).show();
        });

        btnSubmit.setOnClickListener(v -> {
            // Submit student data (placeholder)
            String name = etStudentName.getText().toString();
            String id = etStudentId.getText().toString();
            if (name.isEmpty() || id.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Student Registered (Placeholder)", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
