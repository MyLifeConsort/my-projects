package com.example.studentbiometriclog;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ViewCoursesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_courses);

        // Example: show course list text
        TextView txtCourses = findViewById(R.id.txtCourses);
        txtCourses.setText("1. Mathematics\n2. Computer Science\n3. Physics\n4. English");
    }
}
