package com.example.studentbiometriclog;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CheckGradesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_grades);

        // Example: show grades
        TextView txtGrades = findViewById(R.id.txtGrades);
        txtGrades.setText("Mathematics: A\nComputer Science: A+\nPhysics: B+\nEnglish: A-");
    }
}
