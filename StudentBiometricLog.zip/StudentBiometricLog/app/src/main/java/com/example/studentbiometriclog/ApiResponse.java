package com.example.studentbiometriclog;
public class ApiResponse {
    private String status;
    private String message;
    private User user;  // nested object from JSON

    public String getStatus() { return status; }
    public String getMessage() { return message; }
    public User getUser() { return user; }

    // inner class or separate file
    public static class User {
        private int user_id;
        private String username;
        private String role;

        public int getUser_id() { return user_id; }
        public String getUsername() { return username; }
        public String getRole() { return role; }
    }
}
