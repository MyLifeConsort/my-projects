package com.example.studentbiometriclog;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class AttendanceLogActivity extends AppCompatActivity {

    EditText etFilter;
    ListView lvLogs;
    Button btnExport;
    ArrayAdapter<String> adapter;
    List<String> logs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_log);

        etFilter = findViewById(R.id.etFilter);
        lvLogs = findViewById(R.id.lvLogs);
        btnExport = findViewById(R.id.btnExport);

        // Sample log data
        logs = new ArrayList<>();
        logs.add("John Doe - 2025-07-29 - Present");
        logs.add("Jane Smith - 2025-07-28 - Absent");
        logs.add("Alex Johnson - 2025-07-29 - Present");

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, logs);
        lvLogs.setAdapter(adapter);

        btnExport.setOnClickListener(v -> {
            // Placeholder export action
            Toast.makeText(this, "Exported (Placeholder)", Toast.LENGTH_SHORT).show();
        });

        etFilter.setOnEditorActionListener((v, actionId, event) -> {
            String filterText = etFilter.getText().toString().toLowerCase();
            List<String> filtered = new ArrayList<>();
            for (String log : logs) {
                if (log.toLowerCase().contains(filterText)) {
                    filtered.add(log);
                }
            }
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, filtered);
            lvLogs.setAdapter(adapter);
            return true;
        });
    }
}
