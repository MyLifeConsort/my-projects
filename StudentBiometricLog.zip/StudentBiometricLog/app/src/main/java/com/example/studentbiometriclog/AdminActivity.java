package com.example.studentbiometriclog;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AdminActivity extends AppCompatActivity {

    BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnItemSelectedListener(item -> {
            Fragment f;
            int id = item.getItemId();
            if (id == R.id.nav_dashboard) f = new DashboardFragment();
            else if (id == R.id.nav_students) f = new StudentsFragment();
            else if (id == R.id.nav_courses) f = new CoursesFragment();
            else if (id == R.id.nav_attendance) f = new AttendanceLogFragment();
            else if (id == R.id.nav_teachers) f = new TeachersFragment();
            else f = new DashboardFragment();

            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.admin_nav_host, f)
                    .commit();
            return true;
        });

        // default tab
        if (savedInstanceState == null) {
            bottomNav.setSelectedItemId(R.id.nav_dashboard);
        }
    }
}
