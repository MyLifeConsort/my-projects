package com.example.studentbiometriclog;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AdminDashboardActivity extends AppCompatActivity {

    Button btnRegisterStudent, btnViewReports, btnManageData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard); // ✅ make sure this matches your XML file name

        // Link buttons to their XML IDs
        btnRegisterStudent = findViewById(R.id.btnRegisterStudent);
        btnViewReports = findViewById(R.id.btnViewReports);
        btnManageData = findViewById(R.id.btnManageData);

        // Example: Add click behavior (can be changed later)
        btnRegisterStudent.setOnClickListener(v -> {
            // TODO: Navigate to Register Student screen
        });

        btnViewReports.setOnClickListener(v -> {
            // TODO: Navigate to Report Screen
        });

        btnManageData.setOnClickListener(v -> {
            // TODO: Navigate to Manage Data screen
        });
    }
}
