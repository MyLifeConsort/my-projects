package com.example.studentbiometriclog;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class FaceRecognitionAttendanceActivity extends AppCompatActivity {

    private static final int CAMERA_REQUEST_CODE = 100;
    Button btnStartFaceRecognition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_face_recognition_attendance);

        btnStartFaceRecognition = findViewById(R.id.btnStartFaceRecognition);

        btnStartFaceRecognition.setOnClickListener(v -> {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST_CODE);
            } else {
                startFaceRecognition();
            }
        });
    }

    private void startFaceRecognition() {
        // Placeholder — here you would add ML Kit / OpenCV logic
        Toast.makeText(this, "Face recognized ✅ Attendance marked", Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startFaceRecognition();
            } else {
                Toast.makeText(this, "Camera permission denied ❌", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
