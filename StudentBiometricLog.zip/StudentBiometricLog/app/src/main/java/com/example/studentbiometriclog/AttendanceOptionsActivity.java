package com.example.studentbiometriclog;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class AttendanceOptionsActivity extends AppCompatActivity {

    Button btnFingerprint, btnFaceRecognition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_options);

        btnFingerprint = findViewById(R.id.btnFingerprint);
        btnFaceRecognition = findViewById(R.id.btnFaceRecognition);

        // Fingerprint option
        btnFingerprint.setOnClickListener(v -> {
            Intent intent = new Intent(AttendanceOptionsActivity.this, FingerprintAttendanceActivity.class);
            startActivity(intent);
        });

        // Face Recognition option
        btnFaceRecognition.setOnClickListener(v -> {
            Intent intent = new Intent(AttendanceOptionsActivity.this, FaceRecognitionAttendanceActivity.class);
            startActivity(intent);
        });
    }
}
