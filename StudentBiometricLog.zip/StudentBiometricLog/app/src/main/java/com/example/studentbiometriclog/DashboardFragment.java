package com.example.studentbiometriclog;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DashboardFragment extends Fragment {

    private BottomNavigationView bottomNav() {
        return getActivity().findViewById(R.id.bottom_navigation);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_dashboard, container, false);

        // Card click listeners
        CardView cStudents = v.findViewById(R.id.card_total_students);
        CardView cCourses  = v.findViewById(R.id.card_courses);
        CardView cTeachers = v.findViewById(R.id.card_teachers);
        CardView cAttendance = v.findViewById(R.id.card_attendance);
        CardView cGrading = v.findViewById(R.id.card_grading);

        cStudents.setOnClickListener(view -> bottomNav().setSelectedItemId(R.id.nav_students));
        cCourses.setOnClickListener(view -> bottomNav().setSelectedItemId(R.id.nav_courses));
        cTeachers.setOnClickListener(view -> bottomNav().setSelectedItemId(R.id.nav_teachers));
        cAttendance.setOnClickListener(view -> bottomNav().setSelectedItemId(R.id.nav_attendance));

        cGrading.setOnClickListener(view -> {
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.admin_nav_host, new GradingFragment())
                    .addToBackStack("grading")
                    .commit();
        });

        return v;
    }
}
