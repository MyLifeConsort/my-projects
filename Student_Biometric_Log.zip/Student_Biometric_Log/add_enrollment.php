<?php
include 'db_connect.php';

$message = "";

// Fetch courses for dropdown
$coursesResult = $conn->query("SELECT course_id, course_name FROM courses");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = trim($_POST['first_name']);
    $last_name  = trim($_POST['last_name']);
    $email      = trim($_POST['email']);
    $course_id  = intval($_POST['course_id']);
    $enroll_date = $_POST['enrollment_date'];

    // Convert empty email to NULL to avoid duplicate '' error
    $email = $email === '' ? NULL : $email;

    if ($first_name == "" || $last_name == "" || $course_id == 0 || $enroll_date == "") {
        $message = "<div class='alert alert-danger'>Please fill all required fields.</div>";
    } else {
        // Check if student already exists
        $stmt = $conn->prepare("SELECT student_id FROM students WHERE first_name=? AND last_name=? LIMIT 1");
        $stmt->bind_param("ss", $first_name, $last_name);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Student exists, get student_id
            $stmt->bind_result($student_id);
            $stmt->fetch();
        } else {
            // Insert new student
            $insertStudent = $conn->prepare("INSERT INTO students (first_name, last_name, email) VALUES (?, ?, ?)");
            $insertStudent->bind_param("sss", $first_name, $last_name, $email);
            if ($insertStudent->execute()) {
                $student_id = $insertStudent->insert_id;
            } else {
                $message = "<div class='alert alert-danger'>Error adding student: " . $conn->error . "</div>";
            }
        }

        // Check if student_id is valid
        if (isset($student_id)) {
            // Check if enrollment already exists
            $checkEnroll = $conn->prepare("SELECT * FROM enrollments WHERE student_id=? AND course_id=?");
            $checkEnroll->bind_param("ii", $student_id, $course_id);
            $checkEnroll->execute();
            $checkEnroll->store_result();

            if ($checkEnroll->num_rows > 0) {
                $message = "<div class='alert alert-danger'>Student already enrolled in this course.</div>";
            } else {
                // Insert enrollment
                $insertEnroll = $conn->prepare("INSERT INTO enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, ?)");
                $insertEnroll->bind_param("iis", $student_id, $course_id, $enroll_date);
                if ($insertEnroll->execute()) {
                    $message = "<div class='alert alert-success'>Enrollment added successfully!</div>";
                } else {
                    $message = "<div class='alert alert-danger'>Error enrolling student: " . $conn->error . "</div>";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Student Biometric Log | Add Enrollment</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

 <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li class="active"><a href="students.php"><i class="fa fa-users"></i> <span>Students</span></a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> <span>Courses</span></a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> <span>Teachers</span></a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> <span>Departments</span></a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> <span>Attendance</span></a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> <span>Class Sessions</span></a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> <span>Enrollments</span></a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> <span>Rooms</span></a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> <span>Users</span></a></li>
      </ul>
    </section>
  </aside>
  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header"><h1>Add Enrollment <small>Add new student enrollment</small></h1></section>
    <section class="content">
      <?= $message; ?>
      <div class="box">
        <div class="box-body">
          <form method="POST" action="">
            <div class="form-group">
              <label>First Name</label>
              <input type="text" name="first_name" class="form-control" required>
            </div>
            <div class="form-group">
              <label>Last Name</label>
              <input type="text" name="last_name" class="form-control" required>
            </div>
            <div class="form-group">
              <label>Email (optional)</label>
              <input type="email" name="email" class="form-control" placeholder="Enter email">
            </div>
            <div class="form-group">
              <label>Course</label>
              <select name="course_id" class="form-control" required>
                <option value="">Select Course</option>
                <?php
                if ($coursesResult && $coursesResult->num_rows > 0) {
                    while ($row = $coursesResult->fetch_assoc()) {
                        echo "<option value='".$row['course_id']."'>".htmlspecialchars($row['course_name'])."</option>";
                    }
                }
                ?>
              </select>
            </div>
            <div class="form-group">
              <label>Enrollment Date</label>
              <input type="date" name="enrollment_date" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Add Enrollment</button>
          </form>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer"><div class="pull-right hidden-xs">Version 1.0</div><strong>© Student Biometric Log</strong></footer>
</div>

<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
