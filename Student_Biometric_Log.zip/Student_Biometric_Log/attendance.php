<?php
include 'db_connect.php';

// Fetch attendance records with student names
$sql = "SELECT a.attendance_id, a.session_id, a.student_id, a.status, a.marked_at,
               s.first_name, s.last_name
        FROM attendance a
        JOIN students s ON a.student_id = s.student_id
        ORDER BY a.marked_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Attendance | Student Biometric Log</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> <span>Students</span></a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> <span>Courses</span></a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> <span>Teachers</span></a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> <span>Departments</span></a></li>
        <li class="active"><a href="attendance.php"><i class="fa fa-check"></i> <span>Attendance</span></a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> <span>Class Sessions</span></a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> <span>Enrollments</span></a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> <span>Rooms</span></a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> <span>Users</span></a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header"><h1>Attendance <small>Manage Attendance Records</small></h1></section>
    <section class="content">
      <a href="add_attendance.php" class="btn btn-primary">Add Attendance</a>
      <div class="box">
        <div class="box-header"><h3 class="box-title">Attendance List</h3></div>
        <div class="box-body">
          <table class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Session ID</th>
                <th>Student Name</th>
                <th>Status</th>
                <th>Marked At</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if ($result && $result->num_rows > 0) {
                  while($attendance = $result->fetch_assoc()) {
                      echo "<tr>";
                      echo "<td>".$attendance['attendance_id']."</td>";
                      echo "<td>".$attendance['session_id']."</td>";
                      echo "<td>".htmlspecialchars($attendance['first_name'].' '.$attendance['last_name'])."</td>";
                      echo "<td>".$attendance['status']."</td>";
                      echo "<td>".date('Y-m-d h:i:s A', strtotime($attendance['marked_at']))."</td>";
                      echo "<td>
                              <a href='edit_attendance.php?id=".$attendance['attendance_id']."' class='btn btn-xs btn-warning'>Edit</a>
                              <a href='delete_attendance.php?id=".$attendance['attendance_id']."' class='btn btn-xs btn-danger'>Delete</a>
                            </td>";
                      echo "</tr>";
                  }
              } else {
                  echo "<tr><td colspan='6'>No attendance records found</td></tr>";
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer"><div class="pull-right hidden-xs">Version 1.0</div><strong>© Student Biometric Log</strong></footer>
</div>

<!-- Scripts -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
