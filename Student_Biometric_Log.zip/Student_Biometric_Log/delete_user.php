<?php
include 'db_connect.php';

$message = "";

// Check if user ID is passed
if (!isset($_GET['id'])) {
    header("Location: users.php");
    exit();
}

$user_id = intval($_GET['id']);

// Fetch user
$result = $conn->query("SELECT * FROM users WHERE user_id = $user_id");
if (!$result || $result->num_rows == 0) {
    header("Location: users.php");
    exit();
}
$user = $result->fetch_assoc();

// Handle deletion
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($conn->query("DELETE FROM users WHERE user_id = $user_id") === TRUE) {
        $message = "<div class='alert alert-success'>User deleted successfully!</div>";
        header("Location: users.php?msg=deleted");
        exit();
    } else {
        $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Student Biometric Log | Delete User</title>
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> Students</a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> Courses</a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> Teachers</a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> Departments</a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> Attendance</a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> Class Sessions</a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> Enrollments</a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> Rooms</a></li>
        <li class="active"><a href="users.php"><i class="fa fa-users"></i> Users</a></li>
      </ul>
    </section>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>Delete User <small>Confirm deletion</small></h1>
    </section>
    <section class="content">
      <?= $message; ?>
      <div class="box box-danger">
        <div class="box-header with-border"><h3 class="box-title">Confirm Deletion</h3></div>
        <div class="box-body">
          <p>Are you sure you want to delete user: <strong><?= htmlspecialchars($user['username']); ?></strong>?</p>
          <form method="POST">
            <button type="submit" class="btn btn-danger">OK</button>
            <a href="users.php" class="btn btn-default">Cancel</a>
          </form>
        </div>
      </div>
    </section>
  </div>

  <footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    <strong>© Student Biometric Log</strong>
  </footer>
</div>
</body>
</html>
