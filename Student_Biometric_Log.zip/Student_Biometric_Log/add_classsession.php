<?php
include 'db_connect.php';
session_start(); // for flash messages
$message = "";

// Fetch existing courses and teachers
$courses = $conn->query("SELECT course_id, course_name FROM courses");
$teachers = $conn->query("SELECT teacher_id, first_name, last_name FROM teachers");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_id = $_POST['course_id'];
    $teacher_id = $_POST['teacher_id'];
    $room_id = $_POST['room_id'];
    $session_date = $_POST['session_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    if (!empty($course_id) && !empty($teacher_id) && !empty($room_id) && !empty($session_date)) {
        $stmt = $conn->prepare("INSERT INTO classsessions (course_id, teacher_id, room_id, session_date, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiisss", $course_id, $teacher_id, $room_id, $session_date, $start_time, $end_time);

        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Class session added successfully!";
            header("Location: classsessions.php");
            exit();
        } else {
            $message = "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $message = "Please fill all required fields.";
    }
}

// Fetch rooms for dropdown
$rooms = $conn->query("SELECT room_id, room_number, building_name FROM rooms");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Student Biometric Log | Add Class Session</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> Students</a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> Courses</a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> Teachers</a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> Departments</a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> Attendance</a></li>
        <li class="active"><a href="classsessions.php"><i class="fa fa-calendar"></i> Class Sessions</a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> Enrollments</a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> Rooms</a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> Users</a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header"><h1>Add Class Session</h1></section>
    <section class="content">

      <?php if($message != ""): ?>
        <div class="alert alert-danger"><?= $message; ?></div>
      <?php endif; ?>

      <div class="box box-primary">
        <div class="box-body">
          <form method="POST" action="">

            <div class="form-group">
              <label>Course</label>
              <select name="course_id" class="form-control" required>
                <option value="">Select Course</option>
                <?php while($course = $courses->fetch_assoc()): ?>
                  <option value="<?= $course['course_id']; ?>"><?= $course['course_name']; ?></option>
                <?php endwhile; ?>
              </select>
            </div>

            <div class="form-group">
              <label>Teacher</label>
              <select name="teacher_id" class="form-control" required>
                <option value="">Select Teacher</option>
                <?php while($teacher = $teachers->fetch_assoc()): ?>
                  <option value="<?= $teacher['teacher_id']; ?>"><?= $teacher['first_name'].' '.$teacher['last_name']; ?></option>
                <?php endwhile; ?>
              </select>
            </div>

            <div class="form-group">
              <label>Room</label>
              <select name="room_id" class="form-control" required>
                <option value="">Select Room</option>
                <?php while($room = $rooms->fetch_assoc()): ?>
                  <option value="<?= $room['room_id']; ?>"><?= $room['room_number'].' ('.$room['building_name'].')'; ?></option>
                <?php endwhile; ?>
              </select>
            </div>

            <div class="form-group">
              <label>Session Date</label>
              <input type="date" name="session_date" class="form-control" required>
            </div>

            <div class="form-group">
              <label>Start Time</label>
              <input type="time" name="start_time" class="form-control" required>
            </div>

            <div class="form-group">
              <label>End Time</label>
              <input type="time" name="end_time" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-primary">Add Session</button>
            <a href="classsessions.php" class="btn btn-default">Cancel</a>
          </form>
        </div>
      </div>

    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer"><div class="pull-right hidden-xs">Version 1.0</div><strong>© Student Biometric Log</strong></footer>
</div>

<!-- Scripts -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
