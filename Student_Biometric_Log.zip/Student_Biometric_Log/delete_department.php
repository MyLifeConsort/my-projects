<?php
include 'db_connect.php';

$message = "";

// Check if department ID is passed
if (!isset($_GET['id'])) {
    header("Location: departments.php");
    exit();
}

$id = intval($_GET['id']);

// Fetch department
$result = $conn->query("SELECT * FROM departments WHERE department_id = $id");

if (!$result || $result->num_rows == 0) {
    header("Location: departments.php");
    exit();
}

$department = $result->fetch_assoc();

// Handle delete confirmation
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "DELETE FROM departments WHERE department_id = $id";
    if ($conn->query($sql) === TRUE) {
        $message = "<div class='alert alert-success'>Department deleted successfully!</div>";
        // Optionally redirect back to departments list after deletion
        header("Location: departments.php");
        exit();
    } else {
        $message = "<div class='alert alert-danger'>Error deleting department: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Delete Department | Student Biometric Log</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> <span>Students</span></a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> <span>Courses</span></a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> <span>Teachers</span></a></li>
        <li class="active"><a href="departments.php"><i class="fa fa-building"></i> <span>Departments</span></a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> <span>Attendance</span></a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> <span>Class Sessions</span></a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> <span>Enrollments</span></a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> <span>Rooms</span></a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> <span>Users</span></a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Delete Department <small>Confirm Deletion</small></h1>
    </section>
    <section class="content">
      <?= $message; ?>
      <div class="box">
        <div class="box-header"><h3 class="box-title">Are you sure you want to delete this department?</h3></div>
        <div class="box-body">
          <p><b>Name:</b> <?= htmlspecialchars($department['department_name']); ?></p>
          <p><b>Code:</b> <?= htmlspecialchars($department['department_code']); ?></p>

          <form method="POST" action="">
            <button type="submit" class="btn btn-danger">Ok </button>
            <a href="departments.php" class="btn btn-default">Cancel</a>
          </form>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    <strong>© Student Biometric Log</strong>
  </footer>
</div>

<!-- Scripts -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
