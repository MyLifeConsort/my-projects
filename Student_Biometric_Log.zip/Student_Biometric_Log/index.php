<?php
include 'db_connect.php';

// Function to safely get count from any table
function getCount($conn, $table, $condition = '1') {
    $sql = "SELECT COUNT(*) AS c FROM `$table` WHERE $condition";
    $result = $conn->query($sql);
    if (!$result) return 0;
    $row = $result->fetch_assoc();
    return $row['c'] ?? 0;
}

// Fetch dynamic counts
$students_count      = getCount($conn, 'students');
$courses_count       = getCount($conn, 'courses');
$attendance_count    = getCount($conn, 'attendance', "DATE(attendance_date) = CURDATE()");
$teachers_count      = getCount($conn, 'teachers');
$classsessions_count = getCount($conn, 'classsessions');
$departments_count   = getCount($conn, 'departments');
$enrollments_count   = getCount($conn, 'enrollments');
$rooms_count         = getCount($conn, 'rooms');
$users_count         = getCount($conn, 'users');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Student Biometric Log | Dashboard</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b> Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Admin</p>
           
        </div>
      </div>

      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active"><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li class="treeview">
          <a href="#"><i class="fa fa-database"></i> <span>Entities</span>
            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
          </a>
          <ul class="treeview-menu">
            <li><a href="attendance.php"><i class="fa fa-check-square"></i> Attendance <span class="pull-right-container"><small class="label pull-right bg-red"><?php echo $attendance_count; ?></small></span></a></li>
            <li><a href="classsessions.php"><i class="fa fa-clock-o"></i> Class Sessions <span class="pull-right-container"><small class="label pull-right bg-blue"><?php echo $classsessions_count; ?></small></span></a></li>
            <li><a href="courses.php"><i class="fa fa-book"></i> Courses <span class="pull-right-container"><small class="label pull-right bg-green"><?php echo $courses_count; ?></small></span></a></li>
            <li><a href="departments.php"><i class="fa fa-building"></i> Departments <span class="pull-right-container"><small class="label pull-right bg-aqua"><?php echo $departments_count; ?></small></span></a></li>
            <li><a href="enrollments.php"><i class="fa fa-pencil-square-o"></i> Enrollments <span class="pull-right-container"><small class="label pull-right bg-yellow"><?php echo $enrollments_count; ?></small></span></a></li>
            <li><a href="rooms.php"><i class="fa fa-home"></i> Rooms <span class="pull-right-container"><small class="label pull-right bg-green"><?php echo $rooms_count; ?></small></span></a></li>
            <li><a href="students.php"><i class="fa fa-graduation-cap"></i> Students <span class="pull-right-container"><small class="label pull-right bg-yellow"><?php echo $students_count; ?></small></span></a></li>
            <li><a href="teachers.php"><i class="fa fa-user"></i> Teachers <span class="pull-right-container"><small class="label pull-right bg-aqua"><?php echo $teachers_count; ?></small></span></a></li>
            <li><a href="users.php"><i class="fa fa-users"></i> Users <span class="pull-right-container"><small class="label pull-right bg-red"><?php echo $users_count; ?></small></span></a></li>
          </ul>
        </li>
      </ul>
    </section>
  </aside>

  <!-- Content Wrapper -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Dashboard <small>Student Biometric Control Panel</small></h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-aqua">
            <div class="inner"><h3><?php echo $students_count; ?></h3><p>Students</p></div>
            <div class="icon"><i class="ion ion-person-stalker"></i></div>
            <a href="students.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
            <div class="inner"><h3><?php echo $courses_count; ?></h3><p>Courses</p></div>
            <div class="icon"><i class="ion ion-book"></i></div>
            <a href="courses.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-yellow">
            <div class="inner"><h3><?php echo $attendance_count; ?></h3><p>Today's Attendance</p></div>
            <div class="icon"><i class="ion ion-checkmark-round"></i></div>
            <a href="attendance.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-red">
            <div class="inner"><h3><?php echo $teachers_count; ?></h3><p>Teachers</p></div>
            <div class="icon"><i class="ion ion-person"></i></div>
            <a href="teachers.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
      </div>

      <!-- Second row for remaining entities -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-blue">
            <div class="inner"><h3><?php echo $classsessions_count; ?></h3><p>Class Sessions</p></div>
            <div class="icon"><i class="fa fa-clock-o"></i></div>
            <a href="classsessions.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-aqua">
            <div class="inner"><h3><?php echo $departments_count; ?></h3><p>Departments</p></div>
            <div class="icon"><i class="fa fa-building"></i></div>
            <a href="departments.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-yellow">
            <div class="inner"><h3><?php echo $enrollments_count; ?></h3><p>Enrollments</p></div>
            <div class="icon"><i class="fa fa-pencil-square-o"></i></div>
            <a href="enrollments.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
            <div class="inner"><h3><?php echo $rooms_count; ?></h3><p>Rooms</p></div>
            <div class="icon"><i class="fa fa-home"></i></div>
            <a href="rooms.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
      </div>

      <!-- Third row for Users -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-red">
            <div class="inner"><h3><?php echo $users_count; ?></h3><p>Users</p></div>
            <div class="icon"><i class="fa fa-users"></i></div>
            <a href="users.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
      </div>

    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs"><b>Version</b>1.0</div>
    <strong>&copy; 2025 Student Biometric Log</strong>
  </footer>
</div>

<!-- JS -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
