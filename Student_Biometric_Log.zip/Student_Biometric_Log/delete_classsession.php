<?php
include 'db_connect.php';
session_start(); // Start session to store flash messages

// Check if session ID is passed
if (!isset($_GET['id'])) {
    header("Location: classsessions.php");
    exit();
}

$session_id = intval($_GET['id']);

// Fetch session record with course, teacher, and room details
$result = $conn->query("
    SELECT cs.*, 
           c.course_name, 
           CONCAT(t.first_name, ' ', t.last_name) AS teacher_name,
           r.room_number, r.building_name
    FROM classsessions cs
    JOIN courses c ON cs.course_id = c.course_id
    JOIN teachers t ON cs.teacher_id = t.teacher_id
    JOIN rooms r ON cs.room_id = r.room_id
    WHERE cs.session_id = $session_id
");

if (!$result || $result->num_rows == 0) {
    header("Location: classsessions.php");
    exit();
}

$session = $result->fetch_assoc();

// Handle delete confirmation
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "DELETE FROM classsessions WHERE session_id = $session_id";
    if ($conn->query($sql) === TRUE) {
        // Set flash message
        $_SESSION['success_message'] = "Class session deleted successfully!";
        header("Location: classsessions.php");
        exit();
    } else {
        $message = "<div class='alert alert-danger'>Error deleting session: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Delete Class Session | Student Biometric Log</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> Students</a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> Courses</a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> Teachers</a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> Departments</a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> Attendance</a></li>
        <li class="active"><a href="classsessions.php"><i class="fa fa-calendar"></i> Class Sessions</a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> Enrollments</a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> Rooms</a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> Users</a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Delete Class Session <small>Confirm Deletion</small></h1>
    </section>
    <section class="content">
      <?= isset($message) ? $message : ''; ?>
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Are you sure you want to delete this class session?</h3>
        </div>
        <div class="box-body">
          <p><b>Course:</b> <?= htmlspecialchars($session['course_name']); ?></p>
          <p><b>Teacher:</b> <?= htmlspecialchars($session['teacher_name']); ?></p>
          <p><b>Room:</b> <?= htmlspecialchars($session['room_number'] . ', ' . $session['building_name']); ?></p>
          <p><b>Date:</b> <?= htmlspecialchars($session['session_date']); ?></p>
          <p><b>Start Time:</b> <?= date("h:i A", strtotime($session['start_time'])); ?></p>
          <p><b>End Time:</b> <?= date("h:i A", strtotime($session['end_time'])); ?></p>

          <form method="POST" action="">
            <button type="submit" class="btn btn-danger">Ok</button>
            <a href="classsessions.php" class="btn btn-default">Cancel</a>
          </form>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    <strong>© Student Biometric Log</strong>
  </footer>
</div>

<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
