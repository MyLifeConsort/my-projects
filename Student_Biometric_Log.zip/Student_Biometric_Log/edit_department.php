<?php
include 'db_connect.php';

$message = "";

// Check if department ID is passed in URL
if (!isset($_GET['id'])) {
    // Redirect to departments list if ID is missing
    header("Location: departments.php");
    exit();
}

$id = intval($_GET['id']);

// Fetch department
$result = $conn->query("SELECT * FROM departments WHERE department_id = $id");

if (!$result || $result->num_rows == 0) {
    // Redirect if department not found
    header("Location: departments.php");
    exit();
}

$department = $result->fetch_assoc();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $department_name = trim($_POST['department_name']);
    $department_code = trim($_POST['department_code']);

    if (!empty($department_name) && !empty($department_code)) {
        $sql = "UPDATE departments SET department_name='$department_name', department_code='$department_code' WHERE department_id=$id";
        if ($conn->query($sql) === TRUE) {
            $message = "<div class='alert alert-success'>Department updated successfully!</div>";
            // Refresh the data
            $department['department_name'] = $department_name;
            $department['department_code'] = $department_code;
        } else {
            $message = "<div class='alert alert-danger'>Error updating department: " . $conn->error . "</div>";
        }
    } else {
        $message = "<div class='alert alert-warning'>Please fill in both Department Name and Department Code.</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Department | Student Biometric Log</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> <span>Students</span></a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> <span>Courses</span></a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> <span>Teachers</span></a></li>
        <li class="active"><a href="departments.php"><i class="fa fa-building"></i> <span>Departments</span></a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> <span>Attendance</span></a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> <span>Class Sessions</span></a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> <span>Enrollments</span></a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> <span>Rooms</span></a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> <span>Users</span></a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Edit Department <small>Update department details</small></h1>
    </section>
    <section class="content">
      <?= $message; ?>
      <div class="box">
        <div class="box-header"><h3 class="box-title">Department Details</h3></div>
        <div class="box-body">
          <form method="POST" action="">
            <div class="form-group">
              <label for="department_name">Department Name</label>
              <input type="text" class="form-control" id="department_name" name="department_name" value="<?= htmlspecialchars($department['department_name']); ?>" required>
            </div>
            <div class="form-group">
              <label for="department_code">Department Code</label>
              <input type="text" class="form-control" id="department_code" name="department_code" value="<?= htmlspecialchars($department['department_code']); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Department</button>
            <a href="departments.php" class="btn btn-default">Cancel</a>
          </form>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer"><div class="pull-right hidden-xs">Version 1.0</div><strong>© Student Biometric Log</strong></footer>
</div>

<!-- Scripts -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
