<?php
$host = "localhost";     // Database host
$user = "root";          // Default XAMPP MySQL user
$pass = "";              // Default XAMPP MySQL password is empty
$db   = "student_biometric_log";  // Your database name

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
