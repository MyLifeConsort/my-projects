<?php
include 'db_connect.php';

$message = "";

// Get user ID from URL
$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch user details
$result = $conn->query("SELECT * FROM users WHERE user_id = $user_id");
if (!$result || $result->num_rows == 0) {
    header("Location: users.php");
    exit();
}
$user = $result->fetch_assoc();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $role = $_POST['role'];
    $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;

    if ($password) {
        $sql = "UPDATE users SET username='$username', password_hash='$password', role='$role' WHERE user_id=$user_id";
    } else {
        $sql = "UPDATE users SET username='$username', role='$role' WHERE user_id=$user_id";
    }

    if ($conn->query($sql) === TRUE) {
        $message = "<div class='alert alert-success'>User updated successfully!</div>";
        // Refresh user data
        $result = $conn->query("SELECT * FROM users WHERE user_id = $user_id");
        $user = $result->fetch_assoc();
    } else {
        $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Student Biometric Log | Edit User</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> Students</a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> Courses</a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> Teachers</a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> Departments</a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> Attendance</a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> Class Sessions</a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> Enrollments</a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> Rooms</a></li>
        <li class="active"><a href="users.php"><i class="fa fa-users"></i> Users</a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Edit User <small>Update user details</small></h1>
    </section>
    <section class="content">
      <?= $message; ?>
      <div class="box box-primary">
        <div class="box-header with-border"><h3 class="box-title">User Form</h3></div>
        <form method="POST">
          <div class="box-body">
            <div class="form-group">
              <label>Username</label>
              <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($user['username']); ?>" required>
            </div>
            <div class="form-group">
              <label>Password <small>(Leave blank to keep current password)</small></label>
              <input type="password" name="password" class="form-control" placeholder="Enter new password">
            </div>
            <div class="form-group">
              <label>Role</label>
              <select name="role" class="form-control" required>
                <option value="Admin" <?= $user['role']=='Admin' ? 'selected' : ''; ?>>Admin</option>
                <option value="Teacher" <?= $user['role']=='Teacher' ? 'selected' : ''; ?>>Teacher</option>
                <option value="Student" <?= $user['role']=='Student' ? 'selected' : ''; ?>>Student</option>
              </select>
            </div>
          </div>
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Update User</button>
            <a href="users.php" class="btn btn-default">Back</a>
          </div>
        </form>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    <strong>© Student Biometric Log</strong>
  </footer>
</div>

<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
