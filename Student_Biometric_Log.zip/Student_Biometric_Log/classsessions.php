<?php
include 'db_connect.php';
session_start(); // Start session for flash messages

// Fetch all class sessions with course, teacher, and room details
$sql = "
    SELECT cs.session_id, 
           cs.session_date, 
           cs.start_time, 
           cs.end_time, 
           r.room_number, 
           r.building_name, 
           c.course_name, 
           CONCAT(t.first_name, ' ', t.last_name) AS teacher_name
    FROM classsessions cs
    JOIN courses c ON cs.course_id = c.course_id
    JOIN teachers t ON cs.teacher_id = t.teacher_id
    JOIN rooms r ON cs.room_id = r.room_id
";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Student Biometric Log | Class Sessions</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> Students</a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> Courses</a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> Teachers</a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> Departments</a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> Attendance</a></li>
        <li class="active"><a href="classsessions.php"><i class="fa fa-calendar"></i> Class Sessions</a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> Enrollments</a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> Rooms</a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> Users</a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header"><h1>Class Sessions <small>Manage Sessions</small></h1></section>
    <section class="content">

      <!-- Success message after deletion -->
      <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success">
          <?= $_SESSION['success_message']; ?>
        </div>
        <?php unset($_SESSION['success_message']); ?>
      <?php endif; ?>

      <a href="add_classsession.php" class="btn btn-primary">Add New Session</a>
      <div class="box">
        <div class="box-header"><h3 class="box-title">Sessions List</h3></div>
        <div class="box-body">
          <table class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Course</th>
                <th>Teacher</th>
                <th>Date</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Room</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if ($result && $result->num_rows > 0) {
                  while($row = $result->fetch_assoc()) {
                      echo "<tr>";
                      echo "<td>".$row['session_id']."</td>";
                      echo "<td>".$row['course_name']."</td>";
                      echo "<td>".$row['teacher_name']."</td>";
                      echo "<td>".$row['session_date']."</td>";
                      echo "<td>".date("h:i A", strtotime($row['start_time']))."</td>";
                      echo "<td>".date("h:i A", strtotime($row['end_time']))."</td>";
                      echo "<td>".$row['room_number']." (".$row['building_name'].")</td>";
                      echo "<td>
                              <a href='edit_classsession.php?id=".$row['session_id']."' class='btn btn-xs btn-warning'>Edit</a>
                              <a href='delete_classsession.php?id=".$row['session_id']."' class='btn btn-xs btn-danger'>Delete</a>
                            </td>";
                      echo "</tr>";
                  }
              } else {
                  echo "<tr><td colspan='8'>No class sessions found</td></tr>";
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer"><div class="pull-right hidden-xs">Version 1.0</div><strong>© Student Biometric Log</strong></footer>
</div>

<!-- Scripts -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
