<?php
include 'db_connect.php';

$message = "";

// Check if enrollment ID is passed
if (!isset($_GET['id'])) {
    header("Location: enrollments.php");
    exit();
}

$id = intval($_GET['id']);

// Fetch enrollment record with student & course names
$result = $conn->query("
    SELECT e.*, s.first_name, s.last_name, c.course_name
    FROM enrollments e
    JOIN students s ON e.student_id = s.student_id
    JOIN courses c ON e.course_id = c.course_id
    WHERE e.enrollment_id = $id
");

if (!$result || $result->num_rows == 0) {
    header("Location: enrollments.php");
    exit();
}

$enrollment = $result->fetch_assoc();

// Handle delete confirmation
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "DELETE FROM enrollments WHERE enrollment_id = $id";
    if ($conn->query($sql) === TRUE) {
        $message = "<div class='alert alert-success'>Enrollment deleted successfully!</div>";
        header("refresh:2; url=enrollments.php"); // Redirect after 2 seconds
    } else {
        $message = "<div class='alert alert-danger'>Error deleting enrollment: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Delete Enrollment | Student Biometric Log</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> Students</a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> Courses</a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> Teachers</a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> Departments</a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> Attendance</a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> Class Sessions</a></li>
        <li class="active"><a href="enrollments.php"><i class="fa fa-pencil"></i> Enrollments</a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> Rooms</a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> Users</a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Delete Enrollment <small>Confirm Deletion</small></h1>
    </section>
    <section class="content">
      <?= $message; ?>
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Are you sure you want to delete this enrollment?</h3>
        </div>
        <div class="box-body">
          <p><b>Student:</b> <?= htmlspecialchars($enrollment['first_name'] . " " . $enrollment['last_name']); ?></p>
          <p><b>Course:</b> <?= htmlspecialchars($enrollment['course_name']); ?></p>
          <p><b>Enrollment Date:</b> <?= htmlspecialchars($enrollment['enrollment_date']); ?></p>

          <form method="POST" action="">
            <button type="submit" class="btn btn-danger">OK</button>
            <a href="enrollments.php" class="btn btn-default">Cancel</a>
          </form>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    <strong>© Student Biometric Log</strong>
  </footer>
</div>

<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
