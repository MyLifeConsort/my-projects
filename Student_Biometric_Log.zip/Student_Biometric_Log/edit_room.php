<?php
include 'db_connect.php';

$message = "";

// Get room_id from URL
$room_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch room details
$sql = "SELECT * FROM rooms WHERE room_id = $room_id";
$result = $conn->query($sql);

if (!$result || $result->num_rows == 0) {
    header("Location: rooms.php");
    exit();
}

$room = $result->fetch_assoc();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $room_number   = $_POST['room_number'];
    $building_name = $_POST['building_name'];
    $capacity      = $_POST['capacity'];
    $resources     = $_POST['resources'];

    $update = "UPDATE rooms 
               SET room_number='$room_number', building_name='$building_name', 
                   capacity='$capacity', resources='$resources' 
               WHERE room_id=$room_id";

    if ($conn->query($update) === TRUE) {
        $message = "<div class='alert alert-success'>Room updated successfully!</div>";
        // Refresh room data
        $result = $conn->query("SELECT * FROM rooms WHERE room_id = $room_id");
        $room = $result->fetch_assoc();
    } else {
        $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Room | Student Biometric Log</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> Students</a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> Courses</a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> Teachers</a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> Departments</a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> Attendance</a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> Class Sessions</a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> Enrollments</a></li>
        <li class="active"><a href="rooms.php"><i class="fa fa-home"></i> Rooms</a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> Users</a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header"><h1>Edit Room <small>Update room details</small></h1></section>
    <section class="content">

      <?= $message; ?>

      <div class="box box-primary">
        <div class="box-header with-border"><h3 class="box-title">Room Details</h3></div>
        <form method="POST">
          <div class="box-body">

            <!-- Room Number -->
            <div class="form-group">
              <label>Room Number</label>
              <input type="text" name="room_number" class="form-control" value="<?= htmlspecialchars($room['room_number']); ?>" required>
            </div>

            <!-- Building Name -->
            <div class="form-group">
              <label>Building Name</label>
              <input type="text" name="building_name" class="form-control" value="<?= htmlspecialchars($room['building_name']); ?>" required>
            </div>

            <!-- Capacity -->
            <div class="form-group">
              <label>Capacity</label>
              <input type="number" name="capacity" class="form-control" value="<?= htmlspecialchars($room['capacity']); ?>" required>
            </div>

            <!-- Resources -->
            <div class="form-group">
              <label>Resources</label>
              <input type="text" name="resources" class="form-control" value="<?= htmlspecialchars($room['resources']); ?>">
            </div>

          </div>
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Update Room</button>
            <a href="rooms.php" class="btn btn-default">Back</a>
          </div>
        </form>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer"><div class="pull-right hidden-xs">Version 1.0</div><strong>© Student Biometric Log</strong></footer>
</div>

<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
