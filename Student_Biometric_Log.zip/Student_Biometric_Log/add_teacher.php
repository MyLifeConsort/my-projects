<?php
include 'db_connect.php';

$message = "";

// Fetch departments for dropdown
$departments = $conn->query("SELECT department_id, department_name FROM departments");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name    = $_POST['first_name'];
    $last_name     = $_POST['last_name'];
    $email         = $_POST['email'];
    $phone         = $_POST['phone'];
    $department_id = $_POST['department_id'];
    $hire_date     = !empty($_POST['hire_date']) ? $_POST['hire_date'] : date('Y-m-d');

    // Step 1: Insert into Users table
    $username = $email; // use email as username
    $password = md5("default123"); // default password (you can change this)
    $role     = "Teacher";

    $sql_user = "INSERT INTO users (username, password_hash, role) 
                 VALUES ('$username', '$password', '$role')";

    if ($conn->query($sql_user) === TRUE) {
        $user_id = $conn->insert_id; // get new user_id

        // Step 2: Insert into Teachers table
        $sql_teacher = "INSERT INTO teachers (user_id, first_name, last_name, email, phone, department_id, hire_date) 
                        VALUES ('$user_id', '$first_name', '$last_name', '$email', '$phone', '$department_id', '$hire_date')";

        if ($conn->query($sql_teacher) === TRUE) {
            $message = "<div class='alert alert-success'>Teacher added successfully! Default password is <b>default123</b>.</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
        }
    } else {
        $message = "<div class='alert alert-danger'>Error creating user: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Add Teacher | Student Biometric Log</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> <span>Students</span></a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> <span>Courses</span></a></li>
        <li class="active"><a href="teachers.php"><i class="fa fa-user"></i> <span>Teachers</span></a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> <span>Departments</span></a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> <span>Attendance</span></a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> <span>Class Sessions</span></a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> <span>Enrollments</span></a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> <span>Rooms</span></a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> <span>Users</span></a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Add Teacher <small>Create a new teacher</small></h1>
    </section>
    <section class="content">
      <?= $message; ?>
      <div class="box">
        <div class="box-header"><h3 class="box-title">Teacher Information</h3></div>
        <div class="box-body">
          <form method="POST" action="">
            <div class="form-group">
              <label for="first_name">First Name</label>
              <input type="text" name="first_name" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="last_name">Last Name</label>
              <input type="text" name="last_name" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="email">Email </label>
              <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="phone">Phone</label>
              <input type="text" name="phone" class="form-control">
            </div>
            <div class="form-group">
              <label for="department_id">Department</label>
              <select name="department_id" class="form-control" required>
                <option value="">-- Select Department --</option>
                <?php while ($dept = $departments->fetch_assoc()): ?>
                  <option value="<?= $dept['department_id']; ?>"><?= $dept['department_name']; ?></option>
                <?php endwhile; ?>
              </select>
            </div>
            <!-- Hire Date field added -->
            <div class="form-group">
              <label for="hire_date">Hire Date</label>
              <input type="date" name="hire_date" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Add Teacher</button>
            <a href="teachers.php" class="btn btn-default">Cancel</a>
          </form>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    <strong>© Student Biometric Log</strong>
  </footer>
</div>

<!-- Scripts -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
