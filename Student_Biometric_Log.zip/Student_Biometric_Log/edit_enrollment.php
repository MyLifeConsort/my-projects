<?php
include 'db_connect.php';

$message = "";

// Get enrollment_id from URL
$enrollment_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch enrollment details
$result = $conn->query("SELECT * FROM enrollments WHERE enrollment_id = $enrollment_id");
$enrollment = $result->fetch_assoc();

// Fetch dropdown data
$students = $conn->query("SELECT student_id, first_name, last_name FROM students");
$courses = $conn->query("SELECT course_id, course_name FROM courses");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id'];
    $course_id = $_POST['course_id'];
    $enrollment_date = $_POST['enrollment_date'];

    // Check for duplicate enrollment excluding current record
    $check = $conn->query("SELECT * FROM enrollments WHERE student_id=$student_id AND course_id=$course_id AND enrollment_id != $enrollment_id");
    if ($check->num_rows > 0) {
        $message = "<div class='alert alert-danger'>This student is already enrolled in this course!</div>";
    } else {
        $update = "UPDATE enrollments 
                   SET student_id='$student_id', course_id='$course_id', enrollment_date='$enrollment_date' 
                   WHERE enrollment_id=$enrollment_id";
        if ($conn->query($update) === TRUE) {
            $message = "<div class='alert alert-success'>Enrollment updated successfully!</div>";
            $result = $conn->query("SELECT * FROM enrollments WHERE enrollment_id = $enrollment_id");
            $enrollment = $result->fetch_assoc();
        } else {
            $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Enrollment | Student Biometric Log</title>
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> Students</a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> Courses</a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> Teachers</a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> Departments</a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> Attendance</a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> Class Sessions</a></li>
        <li class="active"><a href="enrollments.php"><i class="fa fa-pencil"></i> Enrollments</a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> Rooms</a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> Users</a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header"><h1>Edit Enrollment</h1></section>
    <section class="content">

      <?= $message; ?>

      <div class="box box-primary">
        <div class="box-header with-border"><h3 class="box-title">Update Enrollment</h3></div>
        <form method="POST">
          <div class="box-body">

            <!-- Student -->
            <div class="form-group">
              <label>Student</label>
              <select name="student_id" class="form-control select2" required>
                <?php while($s = $students->fetch_assoc()): ?>
                  <option value="<?= $s['student_id'] ?>" <?= ($s['student_id'] == $enrollment['student_id']) ? 'selected' : '' ?>>
                    <?= $s['first_name']." ".$s['last_name'] ?>
                  </option>
                <?php endwhile; ?>
              </select>
            </div>

            <!-- Course -->
            <div class="form-group">
              <label>Course</label>
              <select name="course_id" class="form-control select2" required>
                <?php while($c = $courses->fetch_assoc()): ?>
                  <option value="<?= $c['course_id'] ?>" <?= ($c['course_id'] == $enrollment['course_id']) ? 'selected' : '' ?>>
                    <?= $c['course_name'] ?>
                  </option>
                <?php endwhile; ?>
              </select>
            </div>

            <!-- Enrollment Date -->
            <div class="form-group">
              <label>Enrollment Date</label>
              <input type="date" name="enrollment_date" class="form-control" value="<?= $enrollment['enrollment_date'] ?>" required>
            </div>

          </div>
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Update Enrollment</button>
            <a href="enrollments.php" class="btn btn-default">Back</a>
          </div>
        </form>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer"><strong>© Student Biometric Log</strong></footer>
</div>

<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
  $(document).ready(function() {
    $('.select2').select2({tags: true, width: '100%'});
  });
</script>
</body>
</html>
