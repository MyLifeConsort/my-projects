<?php
include 'db_connect.php';

$message = "";

// Ensure teacher_id is passed
if (!isset($_GET['teacher_id'])) {
    die("Error: Teacher ID is required.");
}

$teacher_id = intval($_GET['teacher_id']);

// Fetch teacher details
$sql = "SELECT * FROM teachers WHERE teacher_id = $teacher_id";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $teacher = $result->fetch_assoc();
} else {
    die("Error: Teacher not found.");
}

// Fetch departments for dropdown
$departments = $conn->query("SELECT department_id, department_name FROM departments");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name    = $_POST['first_name'];
    $last_name     = $_POST['last_name'];
    $email         = $_POST['email'];
    $phone         = $_POST['phone'];
    $department_id = $_POST['department_id'];
    $hire_date     = !empty($_POST['hire_date']) ? $_POST['hire_date'] : date('Y-m-d');

    $sql_update = "UPDATE teachers 
                   SET first_name='$first_name', last_name='$last_name', email='$email', phone='$phone', department_id='$department_id', hire_date='$hire_date'
                   WHERE teacher_id=$teacher_id";

    if ($conn->query($sql_update) === TRUE) {
        $message = "<div class='alert alert-success'>Teacher updated successfully!</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error updating teacher: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Teacher | Student Biometric Log</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> <span>Students</span></a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> <span>Courses</span></a></li>
        <li class="active"><a href="teachers.php"><i class="fa fa-user"></i> <span>Teachers</span></a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> <span>Departments</span></a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> <span>Attendance</span></a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> <span>Class Sessions</span></a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> <span>Enrollments</span></a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> <span>Rooms</span></a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> <span>Users</span></a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Edit Teacher <small>Update teacher details</small></h1>
    </section>
    <section class="content">
      <?= $message; ?>
      <div class="box">
        <div class="box-header"><h3 class="box-title">Teacher Information</h3></div>
        <div class="box-body">
          <form method="POST" action="">
            <div class="form-group">
              <label for="first_name">First Name</label>
              <input type="text" name="first_name" value="<?= $teacher['first_name']; ?>" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="last_name">Last Name</label>
              <input type="text" name="last_name" value="<?= $teacher['last_name']; ?>" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="email">Email </label>
              <input type="email" name="email" value="<?= $teacher['email']; ?>" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="phone">Phone</label>
              <input type="text" name="phone" value="<?= $teacher['phone']; ?>" class="form-control">
            </div>
            <div class="form-group">
              <label for="department_id">Department</label>
              <select name="department_id" class="form-control" required>
                <?php while ($dept = $departments->fetch_assoc()): ?>
                  <option value="<?= $dept['department_id']; ?>" 
                    <?= ($dept['department_id'] == $teacher['department_id']) ? 'selected' : ''; ?>>
                    <?= $dept['department_name']; ?>
                  </option>
                <?php endwhile; ?>
              </select>
            </div>
            <!-- Hire Date field -->
            <div class="form-group">
              <label for="hire_date">Hire Date</label>
              <input type="date" name="hire_date" value="<?= $teacher['hire_date']; ?>" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Update Teacher</button>
            <a href="teachers.php" class="btn btn-default">Cancel</a>
          </form>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    <strong>© Student Biometric Log</strong>
  </footer>
</div>

<!-- Scripts -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
