<?php
include 'db_connect.php';

$message = "";

// Ensure id is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("<div class='alert alert-danger'>Error: Course ID is required. <a href='courses.php'>Go Back</a></div>");
}

$id = intval($_GET['id']);

// Fetch departments for dropdown
$departments = $conn->query("SELECT department_id, department_name FROM departments");

// Fetch course details
$result = $conn->query("SELECT * FROM courses WHERE course_id = $id");

if ($result && $result->num_rows > 0) {
    $course = $result->fetch_assoc();
} else {
    die("<div class='alert alert-danger'>Error: Course not found. <a href='courses.php'>Go Back</a></div>");
}

// Handle update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_name = $conn->real_escape_string($_POST['course_name']);
    $course_code = $conn->real_escape_string($_POST['course_code']);
    $description = $conn->real_escape_string($_POST['description']);
    $department_id = intval($_POST['department_id']);

    $sql = "UPDATE courses 
            SET course_name='$course_name', course_code='$course_code', description='$description', department_id='$department_id'
            WHERE course_id=$id";

    if ($conn->query($sql) === TRUE) {
        $message = "<div class='alert alert-success'>Course updated successfully!</div>";
        // Refresh course details
        $course = $conn->query("SELECT * FROM courses WHERE course_id = $id")->fetch_assoc();
    } else {
        $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Course | Student Biometric Log</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

  <!-- Styles -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> <span>Students</span></a></li>
        <li class="active"><a href="courses.php"><i class="fa fa-book"></i> <span>Courses</span></a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> <span>Teachers</span></a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> <span>Departments</span></a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> <span>Attendance</span></a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> <span>Class Sessions</span></a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> <span>Enrollments</span></a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> <span>Rooms</span></a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> <span>Users</span></a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Edit Course <small>Update Course Details</small></h1>
    </section>
    <section class="content">
      <?= $message; ?>
      <div class="box">
        <div class="box-header"><h3 class="box-title">Course Information</h3></div>
        <div class="box-body">
          <form method="POST" action="">
            <div class="form-group">
              <label for="course_name">Course Name</label>
              <input type="text" name="course_name" value="<?= htmlspecialchars($course['course_name']); ?>" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="course_code">Course Code</label>
              <input type="text" name="course_code" value="<?= htmlspecialchars($course['course_code']); ?>" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="description">Description</label>
              <textarea name="description" class="form-control"><?= htmlspecialchars($course['description']); ?></textarea>
            </div>
            <div class="form-group">
              <label for="department_id">Department</label>
              <select name="department_id" class="form-control" required>
                <option value="">-- Select Department --</option>
                <?php
                if ($departments && $departments->num_rows > 0) {
                  while ($dept = $departments->fetch_assoc()) {
                    $selected = ($course['department_id'] == $dept['department_id']) ? "selected" : "";
                    echo "<option value='{$dept['department_id']}' $selected>{$dept['department_name']}</option>";
                  }
                }
                ?>
              </select>
            </div>
            <button type="submit" class="btn btn-primary">Update Course</button>
            <a href="courses.php" class="btn btn-default">Cancel</a>
          </form>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    <strong>© Student Biometric Log</strong>
  </footer>
</div>

<!-- Scripts -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
