<?php
include 'db_connect.php';

$message = "";

// Get session ID from URL
$session_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch session details
$result = $conn->query("SELECT * FROM classsessions WHERE session_id = $session_id");
if (!$result || $result->num_rows == 0) {
    header("Location: classsessions.php");
    exit();
}
$session = $result->fetch_assoc();

// Fetch courses, teachers, and rooms for dropdowns
$courses = $conn->query("SELECT course_id, course_name FROM courses");
$teachers = $conn->query("SELECT teacher_id, CONCAT(first_name, ' ', last_name) AS teacher_name FROM teachers");
$rooms = $conn->query("SELECT room_id, room_number, building_name FROM rooms");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_id = $_POST['course_id'];
    $teacher_id = $_POST['teacher_id'];
    $room_id = $_POST['room_id'];
    $session_date = $_POST['session_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    $sql = "UPDATE classsessions 
            SET course_id=$course_id, teacher_id=$teacher_id, room_id=$room_id, 
                session_date='$session_date', start_time='$start_time', end_time='$end_time' 
            WHERE session_id=$session_id";

    if ($conn->query($sql) === TRUE) {
        $message = "<div class='alert alert-success'>Class session updated successfully!</div>";
        $result = $conn->query("SELECT * FROM classsessions WHERE session_id = $session_id");
        $session = $result->fetch_assoc();
    } else {
        $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Student Biometric Log | Edit Class Session</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

   <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> <span>Students</span></a></li>
        <li class="active"><a href="courses.php"><i class="fa fa-book"></i> <span>Courses</span></a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> <span>Teachers</span></a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> <span>Departments</span></a></li>
        <li><a href="attendance.php"><i class="fa fa-check"></i> <span>Attendance</span></a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> <span>Class Sessions</span></a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> <span>Enrollments</span></a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> <span>Rooms</span></a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> <span>Users</span></a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Edit Class Session <small>Update session details</small></h1>
    </section>
    <section class="content">
      <?= $message; ?>
      <div class="box box-primary">
        <div class="box-header with-border"><h3 class="box-title">Class Session Form</h3></div>
        <form method="POST">
          <div class="box-body">
            <div class="form-group">
              <label>Course</label>
              <select name="course_id" class="form-control" required>
                <?php while($c = $courses->fetch_assoc()): ?>
                  <option value="<?= $c['course_id']; ?>" <?= $c['course_id']==$session['course_id'] ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($c['course_name']); ?>
                  </option>
                <?php endwhile; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Teacher</label>
              <select name="teacher_id" class="form-control" required>
                <?php while($t = $teachers->fetch_assoc()): ?>
                  <option value="<?= $t['teacher_id']; ?>" <?= $t['teacher_id']==$session['teacher_id'] ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($t['teacher_name']); ?>
                  </option>
                <?php endwhile; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Room</label>
              <select name="room_id" class="form-control" required>
                <?php while($r = $rooms->fetch_assoc()): ?>
                  <option value="<?= $r['room_id']; ?>" <?= $r['room_id']==$session['room_id'] ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($r['room_number'].' ('.$r['building_name'].')'); ?>
                  </option>
                <?php endwhile; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Date</label>
              <input type="date" name="session_date" class="form-control" value="<?= $session['session_date']; ?>" required>
            </div>
            <div class="form-group">
              <label>Start Time</label>
              <input type="time" name="start_time" class="form-control" value="<?= $session['start_time']; ?>" required>
            </div>
            <div class="form-group">
              <label>End Time</label>
              <input type="time" name="end_time" class="form-control" value="<?= $session['end_time']; ?>" required>
            </div>
          </div>
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Update Session</button>
            <a href="classsessions.php" class="btn btn-default">Back</a>
          </div>
        </form>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    <strong>© Student Biometric Log</strong>
  </footer>
</div>

<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
