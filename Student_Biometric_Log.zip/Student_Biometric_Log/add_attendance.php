<?php
include 'db_connect.php';

$message = "";

// Fetch students for dropdown
$students_result = $conn->query("SELECT student_id, first_name, last_name FROM students");

// Fetch valid sessions for dropdown (from 2015 onward)
$sessions_result = $conn->query("SELECT session_id FROM classsessions WHERE session_id >= 2015 ORDER BY session_id ASC");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $session_id = intval($_POST['session_id']);
    $student_id = intval($_POST['student_id']);
    $status = $_POST['status'];
    $marked_at = date('Y-m-d H:i:s'); // store in DB in 24-hour format

    if ($session_id && $student_id && !empty($status)) {
        $sql = "INSERT INTO attendance (session_id, student_id, status, marked_at)
                VALUES ($session_id, $student_id, '$status', '$marked_at')";
        if ($conn->query($sql) === TRUE) {
            $message = "<div class='alert alert-success'>Attendance marked successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
        }
    } else {
        $message = "<div class='alert alert-warning'>Please select session, student, and status.</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Mark Attendance | Student Biometric Log</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini"><b>S</b>BL</span>
      <span class="logo-lg"><b>Student</b>Biometric</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>

  <!-- Sidebar -->
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li><a href="students.php"><i class="fa fa-users"></i> <span>Students</span></a></li>
        <li><a href="courses.php"><i class="fa fa-book"></i> <span>Courses</span></a></li>
        <li><a href="teachers.php"><i class="fa fa-user"></i> <span>Teachers</span></a></li>
        <li><a href="departments.php"><i class="fa fa-building"></i> <span>Departments</span></a></li>
        <li class="active"><a href="attendance.php"><i class="fa fa-check"></i> <span>Attendance</span></a></li>
        <li><a href="classsessions.php"><i class="fa fa-calendar"></i> <span>Class Sessions</span></a></li>
        <li><a href="enrollments.php"><i class="fa fa-pencil"></i> <span>Enrollments</span></a></li>
        <li><a href="rooms.php"><i class="fa fa-home"></i> <span>Rooms</span></a></li>
        <li><a href="users.php"><i class="fa fa-users"></i> <span>Users</span></a></li>
      </ul>
    </section>
  </aside>

  <!-- Content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Mark Attendance <small>Fill details below</small></h1>
    </section>
    <section class="content">
      <?= $message; ?>
      <div class="box">
        <div class="box-header"><h3 class="box-title">Attendance Details</h3></div>
        <div class="box-body">
          <form method="POST" action="">
            <div class="form-group">
              <label for="session_id">Session ID</label>
              <select class="form-control" name="session_id" id="session_id" required>
                <option value="">Select Session</option>
                <?php while($session = $sessions_result->fetch_assoc()): ?>
                  <option value="<?= $session['session_id'] ?>"><?= $session['session_id'] ?></option>
                <?php endwhile; ?>
              </select>
            </div>

            <div class="form-group">
              <label for="student_id">Student</label>
              <select class="form-control" name="student_id" id="student_id" required>
                <option value="">Select Student</option>
                <?php while($student = $students_result->fetch_assoc()): ?>
                  <option value="<?= $student['student_id'] ?>"><?= htmlspecialchars($student['first_name'].' '.$student['last_name']) ?></option>
                <?php endwhile; ?>
              </select>
            </div>

            <div class="form-group">
              <label for="status">Status</label>
              <select class="form-control" name="status" id="status" required>
                <option value="">Select Status</option>
                <option value="Present">Present</option>
                <option value="Absent">Absent</option>
              </select>
            </div>

            <button type="submit" class="btn btn-primary">Mark Attendance</button>
            <a href="attendance.php" class="btn btn-default">Cancel</a>
          </form>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer"><div class="pull-right hidden-xs">Version 1.0</div><strong>© Student Biometric Log</strong></footer>
</div>

<!-- Scripts -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
</body>
</html>
